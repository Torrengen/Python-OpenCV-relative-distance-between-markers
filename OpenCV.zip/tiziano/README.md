# How Do Drones Work
A collection of scripts from my tutorials

* Follow my [youtube channel](https://www.youtube.com/watch?v=TFDWs_DG2QY&index=2&list=PLuteWQUGtU9BcXXr3jCG00uVXFwQJkLRa)
* Find  me on [Linkedin](www.linkedin.com/in/tiziano-fiorenzani-0a856415)
* Read my complete series on [How Do Drones Work](https://www.linkedin.com/pulse/how-do-drones-work-part-1-introduction-tiziano-fiorenzani/)

**SOME FILE NAME MIGHT NOT CORRESPOND TO THE ONE USED IN THE VIDEO. THEY HAVE BEEN RENAMED AS NUMBER_TITLOFTUTORIAL**
